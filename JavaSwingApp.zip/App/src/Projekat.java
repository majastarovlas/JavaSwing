
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;
import static javafx.application.Application.launch;

public class Projekat extends Application {

    private MyArrayList<Integer> list = new MyArrayList<>();
    private PrikazListe view = new PrikazListe();
    private Button btSearch = new Button("Search");
    private Button btInsert = new Button("Insert");
    private Button btDelete = new Button("Delete");
    private Button btTrimToSize = new Button("TrimToSize");
    private TextField tfNumber = new TextField();
    private TextField tfIndex = new TextField();

    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        HBox hBox = new HBox(5);
        hBox.getChildren().addAll(new Label("Enter a value: "),
                tfNumber, new Label("Enter an index: "), tfIndex, btSearch,
                btInsert, btDelete, btTrimToSize);
        hBox.setAlignment(Pos.CENTER);

        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(view);
        borderPane.setBottom(hBox);

        Label lblStatus = new Label();
        borderPane.setTop(lblStatus);
        BorderPane.setAlignment(lblStatus, Pos.CENTER);

        // Create a scene and place it in the stage
        Scene scene = new Scene(borderPane, 500, 250);
        primaryStage.setTitle("Projekat"); 
        primaryStage.setScene(scene); 
        primaryStage.show(); 

        view.repaint();
        tfNumber.setPrefColumnCount(2);
        tfIndex.setPrefColumnCount(2);

        btSearch.setOnAction(e -> {
            lblStatus.setText("");
            if (!list.contains(Integer.parseInt(tfNumber.getText()))) {
                lblStatus.setText("key is not in the list");
            } else {
                lblStatus.setText("key is in the list");
            }
            view.repaint();
        });

        btInsert.setOnAction(e -> {
            lblStatus.setText("");
            if (tfIndex.getText().trim().length() > 0) {
                list.add(Integer.parseInt(tfIndex.getText()), Integer.parseInt(tfNumber.getText()));
            } else {
                list.add(Integer.parseInt(tfNumber.getText()));
            }
            view.repaint();
        });

        btDelete.setOnAction(e -> {
            lblStatus.setText("");
            if (!list.contains(Integer.parseInt(tfNumber.getText()))) {
                lblStatus.setText("key is not in the list");
            } else {
                lblStatus.setText("key is deleted from the list");
                list.remove(new Integer(Integer.parseInt(tfNumber.getText())));
                view.repaint();
            }
        });

        btTrimToSize.setOnAction(e -> {
            list.trimToSize();
            view.repaint();
        });
    }

    /**
     * Main metod je potreban samo za IDE sa ograničenom podrškom za JavaFX.
     * Nije potrebno za pokretanje iz komandne linije.
     */
    public static void main(String[] args) {
        launch(args);
    }

    public class PrikazListe extends Pane {

        private int startingX = 20;
        private int startingY = 20;
        private int sirinaBoxa = 30;
        private int visinaBoxa = 20;

        protected void repaint() {
            getChildren().clear();

            int x = startingX + 10;
            int y = startingY + 10;

            getChildren().add(new Text(
                    startingX + 80, startingY, "size = " + list.size()
                    + " and capacity = " + list.getKapacitet()));
            if (list.size() == 0) {
                getChildren().add(new Text(startingX, startingY, "list is empty."));
            } else {
                getChildren().add(new Text(startingX, startingY, "array list"));

                for (int i = 0; i < list.size(); i++) {
                    Rectangle rectangle = new Rectangle(x, y, sirinaBoxa, visinaBoxa);
                    rectangle.setFill(Color.WHITE);
                    rectangle.setStroke(Color.BLACK);
                    getChildren().add(rectangle);
                    getChildren().add(new Text(x + 10, y + 15, list.get(i) + ""));
                    x = x + sirinaBoxa;
                }
            }

            for (int i = list.size(); i < list.getKapacitet(); i++) {
                Rectangle rectangle = new Rectangle(x, y, sirinaBoxa, visinaBoxa);
                rectangle.setFill(Color.WHITE);
                rectangle.setStroke(Color.BLACK);
                getChildren().add(rectangle);
                getChildren().add(new Line(x + sirinaBoxa, y, x, y + visinaBoxa));
                x = x + sirinaBoxa;
            }
        }
    }

    public class MyArrayList<E> extends MyAbstractList<E> {

        public static final int KAPACITET = 4;
        private E[] niz = (E[]) new Object[KAPACITET];

        public int getKapacitet() {
            return niz.length;
        }

        /**
         * Napravite podrazumevanu listu
         */
        public MyArrayList() {
        }

        /**
         * Napravite listu od niza objekata
         */
        public MyArrayList(E[] objects) {
            for (int i = 0; i < objects.length; i++) {
                add(objects[i]);
            }
        }

        /**
         * Dodajte novi element na navedenom indeksu u ovoj listi
         */
        public void add(int index, E e) {
            prosiriNiz();

            // Pomerite elemente udesno nakon navedenog indeksa
            for (int i = size - 1; i >= index; i--) {
                niz[i + 1] = niz[i];
            }

            // Ubaci novi element u listu [indeks]
            niz[index] = e;

            // Povećaj veličinu za 1
            size++;
        }

        /**
         * Napravite novi veci niz, udvostručite trenutnu veličinu + 1
         */
        private void prosiriNiz() {
            if (size >= niz.length) {
                E[] newData = (E[]) (new Object[size * 2 + 1]);
                System.arraycopy(niz, 0, newData, 0, size);
                niz = newData;
            }
        }

        /**
         * Obrišite listu
         */
        public void clear() {
            niz = (E[]) new Object[KAPACITET];
            size = 0;
        }

        /**
         * Vrati true ako ova lista sadrži element e
         */
        public boolean contains(E e) {
            for (int i = 0; i < size; i++) {
                if (e.equals(niz[i])) {
                    return true;
                }
            }

            return false;
        }

        /**
         * Vrati element sa ove liste po navedenom indeksu
         */
        public E get(int index) {

            if (index < 0 || index > size) {
                return null;

            }
            return niz[index];
        }

        /**
         * Vrati indeks prvog odgovarajućeg elementa na ovoj listi. Vrati
         * -1 ako nema podudaranja.
         */
        public int indexOf(E e) {
            for (int i = 0; i < size; i++) {
                if (e.equals(niz[i])) {
                    return i;
                }
            }

            return -1;
        }

        /**
         * Vrati indeks poslednjeg odgovarajućeg elementa na ovoj listi. Vrati
         * -1 ako nema podudaranja.
         */
        public int lastIndexOf(E e) {
            for (int i = size - 1; i >= 0; i--) {
                if (e.equals(niz[i])) {
                    return i;
                }
            }

            return -1;
        }

        /**
         * Uklonite element na navedenom mestu na ovoj listi. Pomerite sve 
         * naredne elemente ulevo
         * Vrati element koji je uklonjen sa liste
         */
        public E remove(int index) {
            E e = niz[index];

            // Pomerite podatke ulevo
            for (int j = index; j < size - 1; j++) {
                niz[j] = niz[j + 1];
            }

            niz[size - 1] = null; // Ovaj element je sada null

            // Veličina umanjenja
            size--;

            return e;
        }

        /**
         * Zamenite element na navedenom mestu u ovoj listi
         * navedenim elementom.
         */
        public E set(int index, E e) {
            E old = niz[index];
            niz[index] = e;
            return old;
        }

        @Override
        /**
         * Override toString () da biste vratili elemente u listi
         */
        public String toString() {
            StringBuilder result = new StringBuilder("[");

            for (int i = 0; i < size; i++) {
                result.append(niz[i]);
                if (i < size - 1) {
                    result.append(", ");
                }
            }

            return result.toString() + "]";
        }

        /**
         * Smanjuje kapacitet na trenutnu veličinu
         */
        public void trimToSize() {
            if (size != niz.length) { // If size == capacity, no need to trim
                E[] newData = (E[]) (new Object[size]);
                System.arraycopy(niz, 0, newData, 0, size);
                niz = newData;
            }
        }
    }

    public abstract class MyAbstractList<E> implements MyList<E> {

        protected int size = 0; // Veličina liste

        /**
         * Napravite default listu
         */
        protected MyAbstractList() {
        }

        /**
         * Napravite listu od niza objekata
         */
        protected MyAbstractList(E[] objects) {
            for (int i = 0; i < objects.length; i++) {
                add(objects[i]);
            }
        }

        /**
         * Dodajte novi element na kraju ove liste
         */
        public void add(E e) {
            add(size, e);
        }

        /**
         * Vrati true ako ova lista ne sadrži elemente
         */
        public boolean isEmpty() {
            return size == 0;
        }

        /**
         * Vrati broj elemenata na ovoj listi
         */
        public int size() {
            return size;
        }

        /**
         * Obrisi element e ako je obrisan vrati true
         */
        public boolean remove(E e) {
            if (indexOf(e) >= 0) {
                remove(indexOf(e));
                return true;
            } else {
                return false;
            }
        }
    }

    public interface MyList<E> {

        /**
         * Dodajte novi element na kraju ove liste
         */
        public void add(E e);

        /**
         * Dodajte novi element na navedenom indeksu na ovoj listi
         */
        public void add(int index, E e);

        /**
         * Obrišite listu
         */
        public void clear();

        /**
         *Vrati true ako ova lista sadrži element
         */
        public boolean contains(E e);

        /**
         * Vrati element sa ove liste po navedenom indeksu
         */
        public E get(int index);

        /**
         * Vrati indeks prvog odgovarajuceg elementa u ovoj listi. Vrati
         * -1 ako nema podudaranja.
         */
        public int indexOf(E e);

        /**
         *Vrati tačno ako ova lista ne sadrži elemente
         */
        public boolean isEmpty();

        /**
         * Vrati indeks poslednjeg odgovarajućeg elementa na ovoj listi. Vrati
         * -1 ako nema podudaranja.
         */
        public int lastIndexOf(E e);

        /**
         * Remove the first occurrence of the element o from this list. Shift
         * any subsequent elements to the left. Return true if the element is
         * removed.
         */
        public boolean remove(E e);

        /**
         * Remove the element at the specified position in this list Shift any
         * subsequent elements to the left. Return the element that was removed
         * from the list.
         */
        public E remove(int index);

        /**
         * Zamenite element na navedenom mestu u ovoj listi
         * navedenim elementom i vraca novi set.
         */
        public Object set(int index, E e);

        /**
         * Vrati broj elemenata u ovoj listi
         */
        public int size();
    }

}
